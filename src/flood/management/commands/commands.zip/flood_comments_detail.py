import asyncio
import json
import sys
import time

import requests
from django.conf import settings
from django.core.management import BaseCommand
import asyncio

from django.db.models import Q

from flood.models import ParsingTaskBloggerStatus, ParsingTaskTypeName, ParsingTaskMicroservice
from flood.modules.CommentsDetail import CommentsDetail
from flood.services.global_service import check_result
from parsing.AsyncParsingNew.utils import time_print


# flood_comments_detail
class Command(BaseCommand):
    help = "Runs consumer."

    def handle(self, *args, **options):
        print("started ")
        loop = asyncio.get_event_loop()
        loop.create_task(worker())
        loop.run_forever()


async def worker():
    q = (Q(status=ParsingTaskBloggerStatus.in_process) & Q(task_type_id=ParsingTaskTypeName.comments.value))
    # http://46.148.235.183:4444/api/results/220/

    while True:

        parsing_tasks = ParsingTaskMicroservice.objects.select_related('task_blogger', 'task_blogger__blogger') \
            .filter(q)
        for parsing_task in parsing_tasks:
            data_link = check_result(parsing_task.parser_task_id)
            # time_print(parsing_task.task_blogger.blogger.login, 'data link', data_link)
            if data_link is None:
                continue
            response = requests.get(f'{settings.MICROSERVICE_IP}{data_link}')
            try:
                if parsing_task.task_blogger.blogger is not None:
                    time_print(parsing_task.task_blogger.blogger.login, 'read data')
                if parsing_task.extra_info is None:
                    parsing_task.status = ParsingTaskBloggerStatus.error
                    parsing_task.save(update_fields=['status'])
                    continue

                await CommentsDetail.from_file(response, parsing_task.extra_info['post_id'])
                if parsing_task.task_blogger.blogger is not None:
                    time_print(parsing_task.task_blogger.blogger.login, 'done flood')
                parsing_task.status = ParsingTaskBloggerStatus.done
            except Exception as e:
                print(e)
                print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e)

                parsing_task.status = ParsingTaskBloggerStatus.error
            parsing_task.save(update_fields=['status'])


        time.sleep(10)
