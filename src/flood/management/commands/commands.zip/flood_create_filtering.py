import os

from django.core.management import BaseCommand
import asyncio

# flood_create_filtering
from django.utils import timezone

from flood.management.commands.flood_task_creator import post_method
from flood.models import ParsingTaskTypeName, ParsingTaskMicroservice, ParsingTaskBlogger, ParsingTaskBloggerStatus, \
    ParsingTaskBloggerType
from main.models import Blogger, Subscriber
from parsing.AsyncParsingNew.utils import time_print


class Command(BaseCommand):
    help = "Runs consumer."

    def handle(self, *args, **options):
        print("started ")
        loop = asyncio.get_event_loop()
        loop.run_until_complete(worker())
        # loop.create_task(worker())
        # loop.run_forever()


def create_filtering(subs_socials_id: list):
    task_id = post_method(ParsingTaskTypeName.filtering.value, subs_socials_id)
    result, cr = ParsingTaskBlogger.objects.get_or_create(blogger=None, day=timezone.now().date(),
                                                          defaults={'status': ParsingTaskBloggerStatus.in_process,
                                                                    'task_type': ParsingTaskBloggerType.one_time
                                                                    })
    ParsingTaskMicroservice.objects.get_or_create(task_blogger=result,
                                                  task_type_id=ParsingTaskTypeName.filtering.value,
                                                  task_type_name=ParsingTaskTypeName.filtering.name,
                                                  parser_task_id=task_id,
                                                  defaults={"status": ParsingTaskBloggerStatus.in_process})


async def worker():
    with open('top_20', 'r', encoding='utf-8') as f:
        top_bloggers = f.read().strip().split('\n')
    ids = Blogger.objects.filter(login__in=top_bloggers, social_network_type_id=3).values_list('id', flat=True)
    try:
        with open('current_id', 'r') as f:
            current_id = int(f.read().strip())
    except:
        current_id = 1
    while True:
        subs = list(Subscriber.objects.filter(id__gt=current_id, bloggers__overlap=list(ids), avatar=None)
                    .order_by('id')[:100]
                    .only('id', 'social_id'))
        current_id = subs[-1].id
        create_filtering([s.social_id for s in subs])

        with open('current_id', 'w') as f:
            f.write(str(current_id))
        time_print('len subs', len(subs))
        await asyncio.sleep(5)

    # for top_blogger in top_bloggers:
    #     blogger = Blogger.objects.get_default(login=top_blogger)
    #     Subscriber.objects.filter_by_blogger(blogger.id)
    #
    # pass
