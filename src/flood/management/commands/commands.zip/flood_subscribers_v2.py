import asyncio

from django.core.management import BaseCommand

# flood_subscribers_v2
from flood.models import ParsingTaskTypeName, ParsingTaskMicroservice
from flood.modules.SubscribersDetail import SubscriberDetail
from flood.modules.FLoodCommand import FloodCommand


class Command(BaseCommand):
    help = "Runs consumer."

    def handle(self, *args, **options):
        print("started ")
        loop = asyncio.get_event_loop()
        loop.run_until_complete(worker())


class FloodSubscribers(FloodCommand):
    def __init__(self, parsing_task_type_name: ParsingTaskTypeName):
        super(FloodSubscribers, self).__init__(parsing_task_type_name)
        self.base_parser = SubscriberDetail

    async def flood_data(self):
        for i, dct in self.parsing_consumer.loop_consume():
            parsing_task: ParsingTaskMicroservice = dct[i['task']]
            log_data = parsing_task.task_blogger.blogger.login
            # log data #warning#

            await self.main_flood(i, parsing_task, log_data)


async def worker():
    # parsing type name #warning
    fc = FloodSubscribers(ParsingTaskTypeName.subscribers)
    await fc.flood_data()
