import asyncio
import os
import time

import django
from django.core.management import BaseCommand

# flood_task_creator_v2

from flood.models import ParsingTaskTypeName, ParsingTaskMicroservice, ParsingTaskBloggerStatus
from flood.modules.TaskCreator import TaskCreator
from parsing.AsyncParsingNew.utils import time_print


class Command(BaseCommand):
    help = "Runs consumer."

    def handle(self, *args, **options):
        print("started ")
        loop = asyncio.get_event_loop()
        loop.run_until_complete(worker())


async def pool_worker(task_type):
    task_type_name, task_type_value = task_type.split(' ')
    print(task_type)

    task_type_value = int(task_type_value)
    status = ParsingTaskBloggerStatus.not_started
    while True:
        tasks = ParsingTaskMicroservice.objects.filter(status=status, task_type_id=task_type_value)
        for task in tasks:
            while True:
                try:
                    await TaskCreator.async_post_method(task)
                    s = f"task name {task_type_name}, task: {task}"
                    time_print(s)
                    break
                except Exception as e:
                    print(e,task.data)
                    await asyncio.sleep(1)
        await asyncio.sleep(10)
        if len(tasks) > 0:
            time_print(f"task name {task_type_name} tasks done")


async def worker():
    task_types = """
        profile_info 4
        subscribers 7
        posts 6
        comments 3
        filtering 8
        blogger_filtering 9
        """
    task_types = list(filter(lambda x: len(x) > 1, list(map(lambda x: x.strip(), task_types.split('\n')))))
    print(task_types)
    await asyncio.gather(*[pool_worker(x) for x in task_types])
