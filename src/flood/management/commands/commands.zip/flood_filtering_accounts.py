import sys
import time

import requests
from django.conf import settings
from django.core.management import BaseCommand
import asyncio

# flood_filtering_accounts
from django.db.models import Q

from flood.models import ParsingTaskMicroservice, ParsingTaskBloggerStatus, ParsingTaskTypeName
from flood.modules.FilteringAccountsDetail import FilteringAccountsDetail
from flood.services.global_service import check_result, check_results
from parsing.AsyncParsingNew.utils import time_print


# flood_filtering_accounts
class Command(BaseCommand):
    help = "Runs consumer."

    def handle(self, *args, **options):
        print("started ")
        loop = asyncio.get_event_loop()
        loop.create_task(worker())
        loop.run_forever()


async def worker():
    q = (Q(status=ParsingTaskBloggerStatus.in_process) & Q(task_type_id=ParsingTaskTypeName.filtering.value))
    # http://46.148.235.183:4444/api/results/220/

    while True:
        dct = {}
        parsing_tasks = ParsingTaskMicroservice.objects.filter(q).order_by('-id').only('parser_task_id', 'status', 'id')

        for p in parsing_tasks:
            dct[p.parser_task_id] = p

        print('tasks parsing', len(parsing_tasks))

        data = check_results(list(dct.keys()))
        # if len(data)>0:
        print('task len got', len(data))
        for i in data:
            parsing_task = dct[i['task']]
            data_link = i['link']

            if data_link is None:
                continue
            response = requests.get(f'{settings.MICROSERVICE_IP}{data_link}')
            try:
                await FilteringAccountsDetail.from_file(response, None)
                time_print(parsing_task.id, 'done flood')
                parsing_task.status = ParsingTaskBloggerStatus.done
            except Exception as e:
                print(e)
                print('Error on line {}'.format(sys.exc_info()[-1].tb_lineno), type(e).__name__, e, 'task',
                      parsing_task.id)
                print(response.text[:20].replace('\n', ' '))

                parsing_task.status = ParsingTaskBloggerStatus.error
            parsing_task.save(update_fields=['status'])

        time.sleep(10)
